const loading= document.querySelector(".loading");

window.addEventListener("load", ()=>
{
    loading.classList.add("loadingFinish");
}, 1000
);